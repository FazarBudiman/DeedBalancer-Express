const app = require('express')
const notes = app.Router()
const controller = require('../Controllers/notesController')
const {verifyToken} = require('../tokenAuth')

notes.get("/:tanggal", verifyToken, controller.getAllNotes )
notes.post("/", verifyToken, controller.addNotes)
notes.put("/:idNotes", verifyToken, controller.updateNotes)
notes.delete("/:idNotes", verifyToken, controller.deleteNotes)

module.exports = notes