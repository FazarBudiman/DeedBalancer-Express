
const db = require("../db")

module.exports = {
    getAllNotes: (req, res) => {
        const id_pengguna = req.cookies["id-pengguna"]
        const { tanggal }  = req.params
        const query = `SELECT id_detail_catatan, waktu, deskripsi, status from catatan c inner join detail_catatan dc  
        on c.id_catatan = dc.id_catatan 
        where id_pengguna = ${id_pengguna} and tanggal LIKE '${tanggal}' `

        // const query = `select * from detail_catatan`
        db.query(query)
        .then((result) => {
            let baik = []
            let buruk = []

            result.map((e, index) => {
                if (e.status == 1) {
                    baik.push(result[index])
                } else if (e.status == 0) {
                    buruk.push(result[index])
                }
            })

            res.status(200).send({
                kegiatanBaik: baik,
                kegiatanBuruk: buruk
            })
        }).catch ((err) => {
            console.log(err)
            res.status(400).send({message: err })
        })
    },
    addNotes: (req, res) => {
        const {id_catatan, waktu, deskripsi, status} = req.body
        const id_detail_catatan = Math.floor(Math.random() * 10000)
        const query = `INSERT INTO detail_catatan (id_detail_catatan, id_catatan, waktu, deskripsi, status, createdAt) 
                        VALUES ( ${id_detail_catatan} ,${id_catatan}, '${waktu}', '${deskripsi}', ${status}, now() )`

        db.query(query)
        .then(() => {
            res.status(200).send({message: 'Menambah catatan berhasil'})
        }).catch((err) => {
            res.status(400).send({message: err})
        })
    },

    updateNotes: (req, res) => {
        const {idNotes} = req.params
        const {waktu, deskripsi} = req.body
        const query = `UPDATE detail_catatan set waktu = '${waktu}', deskripsi='${deskripsi}', updatedAt = now() WHERE id_detail_catatan = ${idNotes}`
    
        db.query(query)
        .then(() => {
            res.status(200).send({message: 'Memperbarui Catatan Berhasil'})
        }).catch((err) => {
            res.status(400).send({message: err})
        })
    },

    deleteNotes: (req, res) => {
        const {idNotes} = req.params
        const query = `DELETE FROM detail_catatan WHERE id_detail_catatan = ${idNotes}`

        db.query(query)
        .then(() => {
            res.status(200).send({message: 'Menghapus catatan Berhasil'})
        }).catch((err) => {
            res.status(400).send({message: err})
        })
    }
}